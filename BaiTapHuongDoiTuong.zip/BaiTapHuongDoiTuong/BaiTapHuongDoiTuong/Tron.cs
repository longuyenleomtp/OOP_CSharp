﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTapHuongDoiTuong
{
    class Tron:Hinh
    {
        private double r;
        public double R {
            get { return r; }
            set { r = value; }
        }

        public Tron():base() {

        }
        public Tron(string tenHinh, double r):base(tenHinh)
        {
            this.r = r;
        }
        public double tinhChuVi()
        {
            double pi = 3.14;
            return 2 * pi * this.r;
        }

        public double tinhDienTich()
        {
            double pi = 3.14;
            return pi * this.r * this.r;
        }
        public void XuatTron()
        {
            Console.WriteLine("Ban kinh " + this.r);
            Console.WriteLine("Chu vi: " + tinhChuVi());
            Console.WriteLine("Dien tich: " + tinhDienTich());
        }

        public void NhapTron()
        {
            Console.WriteLine("Ban kinh: ");
            this.r = double.Parse(Console.ReadLine());
        }


      
    }
}
