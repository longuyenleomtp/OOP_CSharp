﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTapHuongDoiTuong
{
    class TamGiac:Hinh
    {
        private int a,b,c;

        public int A
        {
            get {return a;}
            set {a = value;}
        }
        public int B
        {
            get { return b; }
            set { b = value; }
        }
        public int C
        {
            get { return c; }
            set { c = value; }
        }

        public TamGiac():base() {

        }

        public TamGiac(String tenHinh, int  a, int b, int c):base(tenHinh)
        {
            this.a = a;
            this.b = b;
            this.c = c;
        }

        public double tinhChuVi()
        {
            return this.a + this.b + this.c;
        }

        public double tinhDienTich()
        {
            double p = tinhChuVi() / 2;
            return Math.Sqrt(p * (p - a) * (p - b) * (p - c));
        }

        public void XuatTamgiac()
        {
            Console.WriteLine("Canh A: " + this.a);
            Console.WriteLine("Canh B: " + this.b);
            Console.WriteLine("Canh C: " + this.c);
            Console.WriteLine("Chu vi: " + tinhChuVi());
            Console.WriteLine("Dien tich: " + tinhDienTich());
        }

        public void NhapTamgiac()
        {
            Console.WriteLine("Canh A: ");
            this.a = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Canh B: ");
            this.b = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Canh C: ");
            this.c = Int32.Parse(Console.ReadLine());
        }

        


    }
}
