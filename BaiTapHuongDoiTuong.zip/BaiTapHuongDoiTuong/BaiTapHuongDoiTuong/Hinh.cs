﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTapHuongDoiTuong
{
    class Hinh
    {
        private string tenHinh;
        protected string HINH
        {
            get { return tenHinh; }
            set { tenHinh = value; }
        }
        
        public Hinh()
        {
           
        }

        public Hinh(string tenHinh)
        {
            this.tenHinh = tenHinh;
        }       

        public void NhapHinh() {
            Console.Write("Nhap ten hinh: ");
            this.tenHinh = Console.ReadLine();
        }

        public void XuatHinh()
        {
            Console.Write("Nhap ten hinh: " + this.tenHinh);
        }

        static void Main(string[] args)
        {
          //ChuNhat cn = new ChuNhat();
          //cn.NhapHinh();
          //cn.NhapChunhat();
          //cn.XuatHinh();
          //cn.XuatChunhat();

          Tron tr = new Tron();
          tr.NhapHinh();
          tr.NhapTron();
          tr.XuatHinh();
          tr.XuatTron();

          TamGiac tg = new TamGiac();
          tg.NhapHinh();
          tg.NhapTamgiac();
          tg.XuatHinh();
          tg.XuatTamgiac();


          Console.ReadKey();
        }
       
    }
}
