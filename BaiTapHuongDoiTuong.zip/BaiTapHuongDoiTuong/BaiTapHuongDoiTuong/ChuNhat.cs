﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaiTapHuongDoiTuong
{
    class ChuNhat:Hinh
    {
        private int a,b;
        public int A
        {
            get { return a; }
            set { a = value; }
        }
        public int B
        {
            get { return b; }
            set { b = value; }
        }
        public ChuNhat():base() {

        }

        public ChuNhat(String tenHinh, int a, int b):base(tenHinh)
        {
            this.a = a;
            this.b = b;
        }
        public double tinhChuVi()
        {
            return (this.a + this.b) * 2;
        }

        public double tinhDienTich()
        {
            return a * b;
        }

        public void XuatChunhat()
        {
            Console.WriteLine("Canh dai: " + this.a);
            Console.WriteLine("Canh rong: " + this.b);
            Console.WriteLine("Chu vi: " + tinhChuVi());
            Console.WriteLine("Dien tich: " + tinhDienTich());
        }

        public void NhapChunhat()
        {
            Console.WriteLine("Canh dai: ");
            this.a = Int32.Parse(Console.ReadLine());
            Console.WriteLine("Canh rong: ");
            this.b = Int32.Parse(Console.ReadLine());
        }

        
    }
}
